package com.example.klinik

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.ByteArrayInputStream
import java.lang.Exception

class Dokter : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dokter)

        val rv_dokter: RecyclerView =findViewById(R.id.rv_dokter)
        val id_dokter:MutableList<String> = mutableListOf();
        val nama_dokter: MutableList<String> = mutableListOf();
        val spesialis: MutableList<String> = mutableListOf();
        val foto_dokter: MutableList<Bitmap> = mutableListOf();
        val db : SQLiteDatabase = openOrCreateDatabase("klinik", MODE_PRIVATE, null)
        val gali_dokter = db.rawQuery("SELECT * FROM dokter", null)
        while (gali_dokter.moveToNext())
        {
            try {
                val bis = ByteArrayInputStream(gali_dokter.getBlob(3))
                val gambarbitmap: Bitmap =BitmapFactory.decodeStream(bis)
                foto_dokter.add(gambarbitmap)

            }catch (e: Exception){
                val gambarbitmap= BitmapFactory.decodeResource(this.resources,R.drawable.noimage)
                foto_dokter.add(gambarbitmap)
            }
            id_dokter.add(gali_dokter.getString(0))
            nama_dokter.add(gali_dokter.getString(1))
            spesialis.add(gali_dokter.getString(2))

        }

        val mi = Dokter_item(this, id_dokter, nama_dokter, spesialis, foto_dokter)
        rv_dokter.adapter = mi
        rv_dokter.layoutManager = GridLayoutManager(this, 1)

        val btn_tambah: Button = findViewById(R.id.btn_tambah)
        val btn_kembali: Button = findViewById(R.id.btn_kembali)
        btn_tambah.setOnClickListener {
            val pindah: Intent = Intent(this, Dokter_tambah::class.java)
            startActivity(pindah)
        }
        btn_kembali.setOnClickListener {
            val kembali: Intent = Intent(this,Dashboard::class.java)
            startActivity(kembali)
        }



    }
}
