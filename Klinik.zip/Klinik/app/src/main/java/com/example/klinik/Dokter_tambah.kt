package com.example.klinik

import android.app.Activity
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import androidx.activity.result.contract.ActivityResultContracts
import java.io.ByteArrayOutputStream

class Dokter_tambah : AppCompatActivity() {

    var iv_upload: ImageView? = null
    var urlgambar: Uri? = null
    var bitmapgambar: Bitmap? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dokter_tambah)

        val edit_dokter: EditText = findViewById(R.id.edit_dokter)
        val edit_spesialis: EditText = findViewById(R.id.edit_spesialis)
        val btn_simpan: Button = findViewById(R.id.btn_simpan)
        val btn_kembali: Button = findViewById(R.id.btn_kembali)

        iv_upload = findViewById(R.id.iv_upload)

        iv_upload?.setOnClickListener {
            val bukagaleri: Intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI)
            pilih_gambar.launch(bukagaleri)
        }
        btn_kembali.setOnClickListener {
            val kembali: Intent = Intent(this, Dokter::class.java)
            startActivity(kembali)
        }
        btn_simpan.setOnClickListener {
            val nama_dokter: String = edit_dokter.text.toString()
            val spesialis: String = edit_spesialis.text.toString()

            val bos = ByteArrayOutputStream()
            bitmapgambar?.compress(Bitmap.CompressFormat.JPEG, 100, bos)
            val bytearraygambar = bos.toByteArray()

            val db: SQLiteDatabase = openOrCreateDatabase("klinik", MODE_PRIVATE, null)

            val sql = "INSERT INTO klinik (nama_dokter,spesialis,foto_dokter) VALUES(?,?,?)"
            val statement = db.compileStatement(sql)
            statement.clearBindings()
            statement.bindString(1, nama_dokter)
            statement.bindString(2, spesialis)
            statement.bindBlob(3, bytearraygambar)
            statement.executeInsert()

            val eksekutor = db.rawQuery("INSERT INTO dokter(nama_dokter,spesialis,foto_dokter) VALUES ('$nama_dokter','$spesialis','$bytearraygambar')", null)
            eksekutor.moveToNext()

            val pindah: Intent = Intent(this, Dokter::class.java)
            startActivity(pindah)

        }
    }

    val pilih_gambar = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == Activity.RESULT_OK) {
            val gambardiperoleh = it.data
            if (gambardiperoleh != null) {
                urlgambar = gambardiperoleh.data
                bitmapgambar = MediaStore.Images.Media.getBitmap(contentResolver, urlgambar)
                iv_upload?.setImageBitmap(bitmapgambar)
            }
        }
    }
}