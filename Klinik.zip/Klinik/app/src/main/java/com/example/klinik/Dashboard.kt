package com.example.klinik

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class Dashboard : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dashboard)

                val iv_Profil: ImageView = findViewById(R.id.iv_Profil)
                val iv_Rumahsakit : ImageView = findViewById(R.id.iv_Rumahsakit)
                val iv_About : ImageView =findViewById(R.id.iv_About)
                val iv_Dokter : ImageView = findViewById(R.id.iv_Dokter)

                iv_Profil.setOnClickListener {
                    val pindahprofil = Intent(this, Profil::class.java)
                    startActivity(pindahprofil)
                }
                iv_Rumahsakit.setOnClickListener {
                    val pindahrumahsakit = Intent(this,Rumah_sakit::class.java)
                    startActivity(pindahrumahsakit)
                }
                iv_About.setOnClickListener {
                    val pindahabout = Intent(this,About::class.java)
                    startActivity(pindahabout)
                }
                iv_Dokter.setOnClickListener{
                    val pindahkedokter = Intent(this,Dokter::class.java)
                    startActivity(pindahkedokter)
                }
            }
        }