package com.example.klinik

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class Rumah_sakit : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.rumah_sakit)

        val txt_kembali: TextView = findViewById(R.id.txt_kembali)

        txt_kembali.setOnClickListener {
            val kembali: Intent = Intent(this, Dashboard::class.java)
            startActivity(kembali)
        }

    }
}


