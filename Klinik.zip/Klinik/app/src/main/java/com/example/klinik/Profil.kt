package com.example.klinik

import android.content.Intent
import android.content.SharedPreferences
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class Profil : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.profil)

        val txt_nama_user:TextView=findViewById(R.id.txt_nama_user)
        val txt_email_user:TextView=findViewById(R.id.txt_email_user)
        val txt_password_user:TextView=findViewById(R.id.txt_password_user)
        val txt_logout:TextView=findViewById(R.id.txt_logout)
        val txt_kembali:TextView=findViewById(R.id.txt_kembali)

        val db:SQLiteDatabase = openOrCreateDatabase("klinik", MODE_PRIVATE, null)
        val tiket: SharedPreferences =getSharedPreferences("user", MODE_PRIVATE)

        val nama_user:String?=tiket.getString("nama_user",null)
        val email_user:String?=tiket.getString("email_user",null)
        val password:String?=tiket.getString("password",null)

        txt_nama_user.text="Nama : "+nama_user
        txt_email_user.text="Email : "+email_user
        txt_password_user.text="Password : "+password

        txt_logout.setOnClickListener {
            val edit_tiket = tiket.edit()
            edit_tiket.clear()
            edit_tiket.commit()
            val keluar:Intent=Intent(this,Login::class.java)
            startActivity(keluar)
        }
        txt_kembali.setOnClickListener {
            val kembali:Intent=Intent(this,Dashboard::class.java)
            startActivity(kembali)
        }





    }
}