package com.example.klinik

import android.app.Activity
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import androidx.activity.result.contract.ActivityResultContracts
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.lang.Exception

class Dokter_ubah : AppCompatActivity() {
    var urlgambar: Uri?=null
    var bitmapgambar: Bitmap?=null
    var iv_upload: ImageView?= null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dokter_ubah)
            val id_dokter_terpilih:String = intent.getStringExtra("id_dokter_terpilih").toString()
            val db: SQLiteDatabase = openOrCreateDatabase("klinik", MODE_PRIVATE, null)
            val ambil = db.rawQuery("SELECT * FROM dokter WHERE id_dokter = '$id_dokter_terpilih'",null)
            if (ambil.moveToNext())
            {
                val isi_dokter:String = ambil.getString(1)
                val isi_spesialis:String = ambil.getString(2)
                val isi_foto:ByteArray=ambil.getBlob(3)
                val edit_dokter: EditText =findViewById(R.id.edit_dokter)
                val edit_spesialis: EditText =findViewById(R.id.edit_spesialis)
                val btn_simpan: Button = findViewById(R.id.btn_simpan)
                val btn_kembali: Button =findViewById(R.id.btn_kembali)
                iv_upload = findViewById(R.id.iv_upload)
                edit_dokter.setText(isi_dokter)
                edit_spesialis.setText(isi_spesialis)
                try {
                    val bis = ByteArrayInputStream(isi_foto)
                    val gambarbitmap: Bitmap = BitmapFactory.decodeStream(bis)
                    iv_upload?.setImageBitmap(gambarbitmap)

                }catch (e: Exception){
                    val gambarbitmap= BitmapFactory.decodeResource(this.resources,R.drawable.noimage)
                    iv_upload?.setImageBitmap(gambarbitmap)
                }
                iv_upload?.setOnClickListener {
                    val bukagaleri: Intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI)
                    pilih_gambar.launch(bukagaleri)
                }
                btn_kembali.setOnClickListener {
                    val kembali: Intent = Intent(this,Dokter::class.java)
                    startActivity(kembali)
                }

                btn_simpan.setOnClickListener {
                    val dokter_baru:String = edit_dokter.text.toString()
                    val spesialis_baru:String = edit_spesialis.text.toString()
                    val bos = ByteArrayOutputStream()
                    bitmapgambar?.compress(Bitmap.CompressFormat.JPEG, 100,bos)
                    val bytearraygambar = bos.toByteArray()
                    val sql = "UPDATE dokter SET nama_dokter=?, spesialis=?,foto_dokter=? WHERE id_dokter='$id_dokter_terpilih'"
                    val statement = db.compileStatement(sql)
                    statement.clearBindings()
                    statement.bindString(1, dokter_baru)
                    statement.bindString(2, spesialis_baru)
                    statement.bindBlob(3, bytearraygambar)
                    statement.executeUpdateDelete()
                    val pindah: Intent = Intent(this, Dokter::class.java)
                    startActivity(pindah)

                }
            }




        }
        val pilih_gambar = registerForActivityResult(ActivityResultContracts.StartActivityForResult()){
            if (it.resultCode== Activity.RESULT_OK){
                val gambardiperoleh = it.data
                if(gambardiperoleh!=null){
                    urlgambar =gambardiperoleh.data
                    bitmapgambar = MediaStore.Images.Media.getBitmap(contentResolver,urlgambar)
                    iv_upload?.setImageBitmap(bitmapgambar)

                }
            }
        }
    }
